﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for information
/// </summary>
public class information
{
    public static int user_id;
    public static string status;
    public static string FIO;
}