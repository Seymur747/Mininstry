﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class users : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            organizationdl(Organization_ddl);
            User_name_edt.Attributes.Add("placeholder", "Ad");
            User_surname_edt.Attributes.Add("placeholder", "Soyad");
            User_email_edt.Attributes.Add("placeholder", "Email");
            User_number_edt.Attributes.Add("placeholder", "Telefon");
            User_password_edt.Attributes.Add("placeholder", "Şifrə");
            submit_password.Attributes.Add("placeholder", "Şifrəni təsdiqlə");
            Status_dd.Items.Add("İstifadəçi");
            Status_dd.Items.Add("Admin");
        }
        SqlDataSource1.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;
        SqlDataSource1.SelectCommand = @"SELECT USERS.ID,USERS.NAME,SURNAME,USERS.EMAIL,ORGANIZATION.NAME AS ORGANIZATION,USERS.PHONENUMBER,PASSWORD,STATUS FROM USERS  
 JOIN ORGANIZATION ON USERS.ORGANIZATION_ID=ORGANIZATION.ID";
    }

    private void organizationdl(DropDownList a)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            adapter.SelectCommand=new SqlCommand("SELECT ID,NAME FROM ORGANIZATION",conn);
                adapter.Fill(dt);
            a.DataSource=dt;
            a.DataValueField="ID";
            a.DataTextField = "NAME";
            a.DataBind();
        }
    }

  
    protected void LoadInfo_btn_Click(object sender, EventArgs e)
    {

        try
        {

            if (ObjectID_hf.Value.Length != 0 && ObjectID_hf.Value != "-1")
            {
                using (SqlConnection Conn = new SqlConnection())
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;

                    SqlCommand Comm = new SqlCommand();
                    Comm.Connection = Conn;


                    Comm.Parameters.Add("@ID", SqlDbType.Int);
                    Comm.Parameters["@ID"].Value = ObjectID_hf.Value;

                    Comm.CommandText = @"SELECT USERS.ID,USERS.NAME,SURNAME,USERS.EMAIL,ORGANIZATION_ID,USERS.PHONENUMBER,PASSWORD,STATUS FROM USERS 
                           JOIN ORGANIZATION ON  USERS.ORGANIZATION_ID=ORGANIZATION.ID WHERE USERS.ID=@ID";

                    Conn.Open();


                    SqlDataReader reader = Comm.ExecuteReader();


                    if (reader.Read())
                    {
                       User_name_edt.Text = reader["Name"].ToString();
                       User_surname_edt.Text = reader["SURNAME"].ToString();
                       User_email_edt.Text = reader["EMAIL"].ToString();

                       string t = reader["PHONENUMBER"].ToString();
                       User_number_edt.Text = t.Substring(6, 7);
                       numberddl.SelectedValue = t.Substring(4, 2);
                       
                       User_password_edt.Text = reader["PASSWORD"].ToString();
                       Organization_ddl.SelectedValue = reader["ORGANIZATION_ID"].ToString();
                       Status_dd.Text = reader["STATUS"].ToString();
                    }
                    else
                    {
                        User_name_edt.Text = "Tapılmadı";
                        User_surname_edt.Text = "Tapılmadı";
                        User_email_edt.Text = "Tapılmadı";
                        User_number_edt.Text = "Tapılmadı";
                        User_password_edt.Text = "Tapılmadı";
                    }

                    reader.Close();
                }
            }
            else
            {
                User_name_edt.Text = "";
                User_surname_edt.Text = "";
                User_email_edt.Text = "";
                User_number_edt.Text = "";
                User_password_edt.Text = "";
                submit_password.Text = "";
                ModalCaption_lb.Text = "Əlavə et";
            }
        }
        catch (SqlException E)
        {
        }
        ScriptManager.RegisterStartupScript(this, this.GetType(), "temp", "<script type=\"text/javascript\">$(document).ready(function() {$('#datatable').dataTable();} );</script>", false);
    }

    protected void Save_btn_Click(object sender, EventArgs e)
    {
        using (SqlConnection Conn = new SqlConnection())
        {
            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;

            SqlCommand Comm = new SqlCommand();
            Comm.Connection = Conn;
             
            if (ObjectID_hf.Value.Length != 0 && ObjectID_hf.Value != "-1")
            {
                Comm.CommandText = @"UPDATE USERS  SET
                                            NAME=@NAME,
                                            SURNAME=@SURNAME,
                                            EMAIL=@EMAIL,
                                            PHONENUMBER=@PHONENUMBER,
                                            PASSWORD=@PASSWORD,
                                            ORGANIZATION_ID=@ORGANIZATION,
                                            STATUS=@STATUS
                                    WHERE
                                        ID = @ID";

                Comm.Parameters.Add("@ID", SqlDbType.Int);
                Comm.Parameters["@ID"].Value = ObjectID_hf.Value;
            }
            else
                Comm.CommandText = @"INSERT INTO USERS(NAME,SURNAME,EMAIL,PHONENUMBER,PASSWORD,ORGANIZATION_ID,STATUS) VALUES(@NAME,@SURNAME,@EMAIL,@PHONENUMBER,@PASSWORD,@ORGANIZATION,@STATUS)";

            Comm.Parameters.Add("NAME", SqlDbType.NVarChar);
            Comm.Parameters["NAME"].Value = User_name_edt.Text;

            Comm.Parameters.Add("SURNAME", SqlDbType.NVarChar);
            Comm.Parameters["SURNAME"].Value = User_surname_edt.Text;

            Comm.Parameters.Add("EMAIL", SqlDbType.NVarChar);
            Comm.Parameters["EMAIL"].Value = User_email_edt.Text;

            Comm.Parameters.Add("PHONENUMBER", SqlDbType.NVarChar);
            Comm.Parameters["PHONENUMBER"].Value = "+994" + numberddl.SelectedValue.ToString() + User_number_edt.Text;

            Comm.Parameters.Add("PASSWORD", SqlDbType.NVarChar);
            Comm.Parameters["PASSWORD"].Value = User_password_edt.Text;

            Comm.Parameters.Add("ORGANIZATION", SqlDbType.NVarChar);
            Comm.Parameters["ORGANIZATION"].Value = Organization_ddl.SelectedValue;

            Comm.Parameters.Add("STATUS", SqlDbType.NVarChar);
            Comm.Parameters["STATUS"].Value = Status_dd.Text;





            Conn.Open();

            try
            {
                Comm.ExecuteNonQuery();
            }
            catch (SqlException E)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "temp", "<script type=\"text/javascript\">$(document).ready(function() {init();$.Notification.notify('error','top left','Səhv aşkarlandi', ''); $(\"#close_btn\").click();} );</script>", false);
                return;
            }

            ObjectsGrid.DataBind();

            ScriptManager.RegisterStartupScript(this, this.GetType(), "temp", "<script type=\"text/javascript\">$(document).ready(function() {init();$.Notification.notify('success','top left','Təsdiq edildi', '');$(\"#close_btn\").click();});</script>", false);
        }
    }
    protected void ObjectsGrid_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "DELETE_user")
        {
            using (SqlConnection Conn = new SqlConnection())
            {
                Conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;

                SqlCommand Comm = new SqlCommand();
                Comm.Connection = Conn;

                Comm.CommandText = @"DELETE FROM USERS WHERE USERS.ID = @ID";

                Comm.Parameters.Add("@ID", SqlDbType.Int);
                Comm.Parameters["@ID"].Value = e.CommandArgument;

                Conn.Open();
                try { Comm.ExecuteNonQuery(); }
                catch (SqlException E)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "temp", "<script type=\"text/javascript\">$(document).ready(function() {init();$.Notification.notify('error','top left','Səhv aşkarlandi', ''); $(\"#close_btn\").click();} );</script>", false);
                    return;
                }


                ObjectsGrid.DataBind();

                ScriptManager.RegisterStartupScript(this, this.GetType(), "temp", "<script type=\"text/javascript\">$(document).ready(function() {init();$.Notification.notify('success','top left','Təsdiq edildi', '');$(\"#close_btn\").click();});</script>", false);
            }
        }
    }
    protected void ObjectsGrid_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        LinkButton l = (LinkButton)e.Item.FindControl("Delete_btn");
        l.Attributes.Add("onclick", "javascript:return confirm('Əminsiniz?')");

    }
}