﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Login_edt.Attributes.Add("placeholder", "Login");
            Password_edt.Attributes.Add("placeholder", "Password");
        }
    }

    protected void Login_btn_click(object Sender, EventArgs e)
    {

        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = @"SELECT ID,Name+' '+Surname as FIO,EMAIL,PASSWORD,STATUS FROM USERS WHERE EMAIL=@LOGIN and PASSWORD=@PASSWORD";
            cmd.Parameters.Add("@LOGIN", SqlDbType.NVarChar);

            cmd.Parameters["@LOGIN"].Value = Login_edt.Text;

            cmd.Parameters.Add("@PASSWORD", SqlDbType.NVarChar);

            cmd.Parameters["@PASSWORD"].Value = Password_edt.Text;

            conn.Open();

            SqlDataReader reader;

            reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                information.user_id = Convert.ToInt32(reader["ID"].ToString());
                information.status = reader["STATUS"].ToString();
                information.FIO = reader["FIO"].ToString();
                reader.Close();
                if (information.status == "Admin") Response.Redirect("NPanel.aspx");//Npanel
                else Response.Redirect("Default2.aspx");//user --> create event
            }

            reader.Close();

            this.RegisterStartupScript("alert", "<script lang='javascript'>alert('User not found');</script>");


        }

    }


}
