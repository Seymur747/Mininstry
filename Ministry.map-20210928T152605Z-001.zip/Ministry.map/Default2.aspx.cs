﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Loginlbl.Text = information.FIO;
        Statuslbl.Text = information.status;
        organizationdl(organizationddl);
        categorydl(categoryddl);
        locationdl(locationddk);
        
    }
    protected void textchanged(object sender, EventArgs e)
    {
       
    }
    private void organizationdl(DropDownList a)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            int user_id = information.user_id;
            adapter.SelectCommand = new SqlCommand("SELECT USERS.ID,ORGANIZATION.NAME AS ORGANIZATION FROM USERS JOIN ORGANIZATION ON USERS.ORGANIZATION_ID=ORGANIZATION.ID  WHERE USERS.ID=" + user_id.ToString(), conn);
           
            adapter.Fill(dt);
            a.DataSource = dt;
            a.DataValueField = "ID";
            a.DataTextField = "ORGANIZATION";
            a.DataBind();
        }
    }

    private void categorydl(DropDownList a)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            int user_id = information.user_id;
            adapter.SelectCommand = new SqlCommand("SELECT ID,NAME FROM CATEGORY", conn);
            adapter.Fill(dt);
            a.DataSource = dt;
            a.DataValueField = "ID";
            a.DataTextField = "NAME";
            a.DataBind();
        }
    }
    private void locationdl(DropDownList a)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            int user_id = information.user_id;
            adapter.SelectCommand = new SqlCommand("SELECT ID,NAME FROM LOCATIONS", conn);
            adapter.Fill(dt);
            a.DataSource = dt;
            a.DataValueField = "ID";
            a.DataTextField = "NAME";
            a.DataBind();
        }
    }

    protected void Save_btn_Click(object sender, EventArgs e)
    {
        using (SqlConnection Conn = new SqlConnection())
        {
            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBPath"].ConnectionString;

            SqlCommand Comm = new SqlCommand();
            Comm.Connection = Conn;


            Comm.CommandText = @"INSERT INTO EVENTS(NAME,ORGANIZATION_ID,LOCATION_ID,CATEGORY_ID,USER_ID,DESCRIPTON,IMAGE,DELETED,TIME) 
                                                       VALUES(@NAME,@ORGANIZATION_ID,@LOCATION_ID,@CATEGORY_ID,@USER_ID,@DESCRIPTON,@IMAGE,@DELETED,@TIME)";

            Comm.Parameters.Add("@NAME", SqlDbType.NVarChar);
            Comm.Parameters["@NAME"].Value = event_name.Text;

            Comm.Parameters.Add("@ORGANIZATION_ID", SqlDbType.Int);
            Comm.Parameters["@ORGANIZATION_ID"].Value = organizationddl.SelectedValue;

            Comm.Parameters.Add("@LOCATION_ID", SqlDbType.Int);
            Comm.Parameters["@LOCATION_ID"].Value = organizationddl.SelectedValue;

            Comm.Parameters.Add("@CATEGORY_ID", SqlDbType.Int);
            Comm.Parameters["@CATEGORY_ID"].Value = categoryddl.SelectedValue;

            Comm.Parameters.Add("@USER_ID", SqlDbType.Int);
            Comm.Parameters["@USER_ID"].Value = information.user_id;

            Comm.Parameters.Add("@DESCRIPTON", SqlDbType.NVarChar);
            Comm.Parameters["@DESCRIPTON"].Value = event_descriton.Text;

            Comm.Parameters.Add("@DELETED", SqlDbType.NVarChar);
            Comm.Parameters["@DELETED"].Value = "true";

            Comm.Parameters.Add("@TIME", SqlDbType.DateTime);
            Comm.Parameters["@TIME"].Value = DateTime.Now;



            //============================= IMAHGE=========================
            Comm.Parameters.Add("@IMAGE", SqlDbType.VarBinary);
            if (FileUpload1.HasFile)
            {
                int filelenght = FileUpload1.PostedFile.ContentLength;
                byte[] imagebytes = new byte[filelenght];
                FileUpload1.PostedFile.InputStream.Read(imagebytes, 0, filelenght);
                Comm.Parameters["@IMAGE"].Value = imagebytes;
            }
            else
                Comm.Parameters["@IMAGE"].Value = DBNull.Value;
            //============================= IMAHGE=========================



            Conn.Open();
            try
            {

                Comm.ExecuteNonQuery();
            }

            catch 
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "temp", "<script type=\"text/javascript\">$(document).ready(function() {init();$.Notification.notify('error','top left','Səhv aşkarlandi', ''); $(\"#close_btn\").click();} );</script>", false);
                return;
            }


            ScriptManager.RegisterStartupScript(this, this.GetType(), "temp", "<script type=\"text/javascript\">$(document).ready(function() {init();$.Notification.notify('success','top left','Təsdiq edildi', '');$(\"#close_btn\").click();});</script>", false);

        }

    }



}